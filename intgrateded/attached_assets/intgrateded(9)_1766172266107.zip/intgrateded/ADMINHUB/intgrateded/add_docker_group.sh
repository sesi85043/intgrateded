#!/bin/bash
usermod -aG docker adminhub
echo "SUCCESS: adminhub added to docker group"
